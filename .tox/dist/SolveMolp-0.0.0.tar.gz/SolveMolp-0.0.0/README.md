# Solving MOLP
 Algorithms for solving MOLP problems 


### To call the function

The input data for MOLP problem should be inputed as an numpy arrays for scipy.optimize.linprog to work. 

For more info: https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.linprog.html



## Refrences: 

[1] H.-J. Zimmermann. Fuzzy programming and linear programming with several
objective functions. Fuzzy Sets and Systems, 1(1):45–55, 1978.
http://dx.doi.org/10.1016/0165-0114(78)90031-3.